package com.devskiller.selenium;

import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.Iterator;
import java.util.Set;


import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;
import static utils.Utility.reader;

public class SeleniumExecutor implements Executor {

    private final WebDriver driver;
    public String text;

    public SeleniumExecutor(WebDriver driver) {
        this.driver = driver;
    }

    By senderNameField = By.xpath("//button[@class=\"wt-btn wt-btn--small wt-btn--transparent wt-mr-xs-1 inline-overlay-trigger signin-header-action select-signin\"]");

    By inputLogin = By.xpath("//input[@id=\"join_neu_email_field\"]");
    By continueLogin = By.xpath(" //button[@class=\"wt-btn wt-btn--primary wt-width-full\"]");

    By inputPassword = By.xpath("//input[@id=\"join_neu_password_field\"]");

    By signIn = By.xpath("//button[@class=\"wt-btn wt-btn--small wt-btn--transparent wt-mr-xs-1 inline-overlay-trigger signin-header-action select-signin\"]");

    By jewllery = By.xpath("(//a[@class=\"wt-text-link-no-underline\"])[1]");
    By Item = By.xpath("//p[text()=\"Embroidery\"]");
    By addBasket = By.xpath("(//button[@class=\"wt-btn wt-btn--filled wt-width-full\"])[1]");
    By selectOption = By.xpath("(//select[@id=\"variation-selector-0\"])[1]\n");
    By optionSelected = By.xpath(" (//option[@value=\"2529600589\"])\n");
    By mainScreenMessage = By.xpath("//h1[@id=\"join-neu-overlay-title\"]");
    //h1[@class="wt-text-heading-01 wt-display-inline wt-mb-xs-2 wt-overflow-hidden"]
    By accessoriesPageTitle = By.xpath("//h1[@class=\"wt-text-heading-01 wt-display-inline wt-mb-xs-2 wt-overflow-hidden\"]");
    By itemSelected = By.xpath("(//div[@class=\"height-placeholder\"])[2]\n");
    By selectColor = By.xpath(" //select[@id=\"variation-selector-0\"]");
    By colorSelected = By.xpath(" //option[@value=\"2699713867\"]");
    By addToBasket = By.xpath("//button[@class=\"wt-btn wt-btn--filled wt-width-full\"]\n");
    By titleExpectedAfterAddedToBasket = By.xpath("//a[@class=\"wt-text-link-no-underline wt-text-body-01 wt-line-height-tight wt-break-word\"]");
    By deliveryValueBeforeUpdation = By.xpath(" (//span[@class=\"currency-value\"])[6]");
    By personalizationText = By.xpath(" //p[@id=\"personalization-instructions\"]");


    /// Page 1
    @Override
    public void SetLoginAndClickNext(String login) throws InterruptedException {
        String senderName = reader().getCellData1("Sheet1", login, 1);


        driver.findElement(signIn).click();
        Thread.sleep(3000);

        driver.findElement(inputLogin).sendKeys(senderName);

//        WebDriverWait wait = new WebDriverWait(driver, 2000);
//
//        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//button[@class=\"wt-btn wt-btn--secondary wt-width-full\"] )[1]")));
//
//        driver.findElement(By.xpath("(//button[@class=\"wt-btn wt-btn--secondary wt-width-full\"])[1]")).click();
//        Thread.sleep(3000);
//        ///////////////////////////////////////////
//
//        String mainWindowHandle = driver.getWindowHandle();
//        Set<String> allWindowHandles = driver.getWindowHandles();
//        Iterator<String> iterator = allWindowHandles.iterator();
//
//        // Here we will check if child window has other child windows and will fetch the heading of the child window
//        while (iterator.hasNext()) {
//            String ChildWindow = iterator.next();
//            if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
//                driver.switchTo().window(ChildWindow);
//                driver.findElement(By.xpath("//input[@type = \"email\"]")).clear();
//                driver.findElement(By.xpath("//input[@type = \"email\"]")).sendKeys("leonardocelvin201@gmail.com");
//                driver.findElement(By.xpath("//span[text()=\"Next\"]")).click();
//Thread.sleep(3000);
//              driver.findElement(By.xpath("//input[@type=\"password\"]")).sendKeys("Leonardocelvin123");
//                driver.findElement(By.xpath("//span[text()=\"Next\"]")).click();
//
//
//        }
//        driver.switchTo().window(mainWindowHandle);

    }

    @Override

    public void SetPassword(String login) throws InterruptedException {

        String name = reader().getCellData1("Sheet1", login, 2);


        Thread.sleep(3000);
        driver.findElement(inputPassword).sendKeys(name);

        driver.findElement(By.xpath("//button[@class=\"wt-btn wt-btn--primary wt-width-full\"]")).click();


    }

    @Override
    public void SelectGiftIdeas() {

    }


    public void SelectJewllery() throws InterruptedException {
        String expectedTitle = "Baseball & Trucker Caps";


//

        WebElement jewl = driver.findElement(By.xpath("(//a[@class=\"wt-text-link-no-underline\"])[1]"));

        Actions action = new Actions(driver);

//Performing the mouse hover action on the target element.
        action.moveToElement(jewl).perform();
        Thread.sleep(3000);

        driver.findElement(By.xpath("(//li[@data-node-id=\"10856\"])[1]")).click();

        driver.findElement(By.xpath("//a[@id=\"catnav-l4-12291\"]")).click();
        String actualTitle = driver.findElement(accessoriesPageTitle).getText();
        Assert.assertEquals(actualTitle, expectedTitle);

    }


    @Override

    public void ShopItem() {
        driver.findElement(Item).click();
        driver.findElement(itemSelected).click();

    }


    public void AddBasket() throws InterruptedException {
        String mainWindowHandle = driver.getWindowHandle();
        Set<String> allWindowHandles = driver.getWindowHandles();
        Iterator<String> iterator = allWindowHandles.iterator();

        // Here we will check if child window has other child windows and will fetch the heading of the child window
        while (iterator.hasNext()) {
            String ChildWindow = iterator.next();
            if (!mainWindowHandle.equalsIgnoreCase(ChildWindow)) {
                driver.switchTo().window(ChildWindow);
                String titleExpectedBeforeAddedToBasket = driver.findElement(By.xpath("//h1[@class=\"wt-text-body-03 wt-line-height-tight wt-break-word\"]")).getText();

                driver.findElement(selectColor).click();
                WebElement element = driver.findElement(By.id("variation-selector-0"));
                Select select = new Select(element);
                select.selectByIndex(1);
                try {
                    driver.findElement(By.xpath("//select[@id=\"variation-selector-1\"]")).click();
                    Thread.sleep(3000);
                    driver.findElement(By.xpath("//option[@value=\"2464038694\"]")).click();

                    Thread.sleep(3000);

                    driver.findElement(By.xpath("//textarea[@class=\"wt-textarea wt-textarea\"]")).sendKeys("ans.jamil1@gmail.com");
                    Thread.sleep(2000);
                    driver.findElement(addToBasket).click();

                } catch (Exception e) {
                    driver.findElement(addToBasket).click();


                }


                String actualTitle = driver.findElement(titleExpectedAfterAddedToBasket).getText();
                Assert.assertEquals(titleExpectedBeforeAddedToBasket, actualTitle);
                String value = driver.findElement(deliveryValueBeforeUpdation).getText();
                UpdateAndVerifyBucket(value);


            }


        }
    }


    private void UpdateAndVerifyBucket(String value) throws InterruptedException {
        System.out.println(value);

        driver.findElement(By.xpath("(//select[@name=\"listing-quantity\"])[2]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//option[@value=\"3\"])[2]")).click();

        String valueAfterUpdation = driver.findElement(By.xpath("(//span[@class=\"currency-value\"])[6]")).getText();
        System.out.println(valueAfterUpdation);

    }


    public void UpdateAndVerifyBucket() {


    }

}
